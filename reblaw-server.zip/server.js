
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
require("dotenv").config();
const fetch = require("node-fetch");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 4000;
const TELEGRAM_BOT_TOKEN = process.env.BOT_TOKEN;

app.post("/api/send-score", async (req, res) => {
  const { userId, rlc } = req.body;

  if (!userId || !rlc) {
    return res.status(400).json({ error: "Missing userId or rlc value" });
  }

  const telegramUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
  const payload = {
    chat_id: userId,
    text: `🎉 شما ${rlc} RLC در بازی حقوقی کسب کردید.`,
  };

  console.log("🛰 ارسال به:", telegramUrl);
  console.log("📦 محتوا:", payload);

  try {
    const response = await fetch(telegramUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await response.json();
    console.log("📥 پاسخ تلگرام:", data);

    if (!data.ok) {
      return res.status(500).json({ success: false, error: data.description });
    }

    res.status(200).json({ success: true, result: data });
  } catch (error) {
    console.error("❌ ارسال به تلگرام ناموفق:", error);
    res.status(500).json({ success: false, error: "ارسال به تلگرام شکست خورد" });
  }
});

app.get("/", (req, res) => {
  res.send("RebLaw Server is Running.");
});

app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
